'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _CloseSquareOutlined = _interopRequireDefault(require('./lib/icons/CloseSquareOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _CloseSquareOutlined;
  exports.default = _default;
  module.exports = _default;