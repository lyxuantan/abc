'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _CarTwoTone = _interopRequireDefault(require('./lib/icons/CarTwoTone'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _CarTwoTone;
  exports.default = _default;
  module.exports = _default;