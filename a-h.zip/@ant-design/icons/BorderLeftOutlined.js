'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _BorderLeftOutlined = _interopRequireDefault(require('./lib/icons/BorderLeftOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _BorderLeftOutlined;
  exports.default = _default;
  module.exports = _default;