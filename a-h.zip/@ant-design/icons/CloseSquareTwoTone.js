'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _CloseSquareTwoTone = _interopRequireDefault(require('./lib/icons/CloseSquareTwoTone'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _CloseSquareTwoTone;
  exports.default = _default;
  module.exports = _default;