'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _DingdingOutlined = _interopRequireDefault(require('./lib/icons/DingdingOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _DingdingOutlined;
  exports.default = _default;
  module.exports = _default;