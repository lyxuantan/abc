'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _ApiTwoTone = _interopRequireDefault(require('./lib/icons/ApiTwoTone'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _ApiTwoTone;
  exports.default = _default;
  module.exports = _default;