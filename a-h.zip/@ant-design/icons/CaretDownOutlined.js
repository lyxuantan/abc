'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _CaretDownOutlined = _interopRequireDefault(require('./lib/icons/CaretDownOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _CaretDownOutlined;
  exports.default = _default;
  module.exports = _default;