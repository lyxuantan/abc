'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _BehanceOutlined = _interopRequireDefault(require('./lib/icons/BehanceOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _BehanceOutlined;
  exports.default = _default;
  module.exports = _default;