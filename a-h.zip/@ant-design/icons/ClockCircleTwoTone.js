'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _ClockCircleTwoTone = _interopRequireDefault(require('./lib/icons/ClockCircleTwoTone'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _ClockCircleTwoTone;
  exports.default = _default;
  module.exports = _default;