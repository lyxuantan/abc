## loadModules
<code src="../examples/loadModules.tsx">
