'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _CaretDownFilled = _interopRequireDefault(require('./lib/icons/CaretDownFilled'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _CaretDownFilled;
  exports.default = _default;
  module.exports = _default;