'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _ChromeOutlined = _interopRequireDefault(require('./lib/icons/ChromeOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _ChromeOutlined;
  exports.default = _default;
  module.exports = _default;