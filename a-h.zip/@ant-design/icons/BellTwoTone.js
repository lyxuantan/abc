'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _BellTwoTone = _interopRequireDefault(require('./lib/icons/BellTwoTone'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _BellTwoTone;
  exports.default = _default;
  module.exports = _default;