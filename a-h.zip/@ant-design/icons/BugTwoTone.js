'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _BugTwoTone = _interopRequireDefault(require('./lib/icons/BugTwoTone'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _BugTwoTone;
  exports.default = _default;
  module.exports = _default;