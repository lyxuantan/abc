'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _ContactsOutlined = _interopRequireDefault(require('./lib/icons/ContactsOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _ContactsOutlined;
  exports.default = _default;
  module.exports = _default;