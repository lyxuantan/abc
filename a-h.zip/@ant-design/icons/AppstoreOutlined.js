'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _AppstoreOutlined = _interopRequireDefault(require('./lib/icons/AppstoreOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _AppstoreOutlined;
  exports.default = _default;
  module.exports = _default;