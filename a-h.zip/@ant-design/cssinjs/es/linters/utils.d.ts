import { LinterInfo } from './interface';
export declare function lintWarning(message: string, info: LinterInfo): void;
