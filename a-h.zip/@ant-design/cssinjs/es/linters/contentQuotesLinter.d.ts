import type { Linter } from './interface';
declare const linter: Linter;
export default linter;
