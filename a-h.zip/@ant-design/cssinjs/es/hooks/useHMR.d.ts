declare function useProdHMR(): boolean;
declare const _default: typeof useProdHMR;
export default _default;
