interface Opts {
    theme?: 'dark' | 'default';
    backgroundColor?: string;
}
export default function generate(color: string, opts?: Opts): string[];
export {};
//# sourceMappingURL=generate.d.ts.map