'use strict';
module.exports = function (re) {
	return Object.prototype.toString.call(re) === '[object RegExp]';
};
