export { default } from './build/test_name_plugin/plugin.js';
